function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6XFNVZMNXNx":
        Script1();
        break;
      case "5UtKyWBCu0X":
        Script2();
        break;
      case "6DCuyC4Q0YM":
        Script3();
        break;
      case "6iADswVq5Aq":
        Script4();
        break;
      case "68qfxC9uRqn":
        Script5();
        break;
      case "5fO9ChswajM":
        Script6();
        break;
      case "6g0nNuHU0oi":
        Script7();
        break;
      case "5ezYs7Cp2qb":
        Script8();
        break;
      case "6pGqgrv7a7z":
        Script9();
        break;
      case "6pLBJ95wfVD":
        Script10();
        break;
      case "5hTRO59Bt3t":
        Script11();
        break;
      case "64OGcCEG2Gh":
        Script12();
        break;
      case "5y7lcChM1K1":
        Script13();
        break;
      case "5h8PDdMuuL7":
        Script14();
        break;
      case "6Ts4g18L0lu":
        Script15();
        break;
      case "6X31dmN3PYH":
        Script16();
        break;
      case "6DIDrjNnWmN":
        Script17();
        break;
      case "5mEIkRNX719":
        Script18();
        break;
      case "5ovs4UYkKRl":
        Script19();
        break;
      case "6qN30FTekqM":
        Script20();
        break;
      case "5YCvcTlMge8":
        Script21();
        break;
      case "6krV9k8SWwD":
        Script22();
        break;
      case "6lN3VB3ck71":
        Script23();
        break;
      case "5uv1Ma2vhxT":
        Script24();
        break;
      case "5qvaMwiO5e8":
        Script25();
        break;
      case "6Rq6wzbOqMC":
        Script26();
        break;
      case "6LHMpu6cBac":
        Script27();
        break;
      case "5bUnMMqgHnF":
        Script28();
        break;
      case "61nBfTeNih8":
        Script29();
        break;
      case "6FNbB8AvexF":
        Script30();
        break;
      case "6HvLlptfTpU":
        Script31();
        break;
      case "612Kk2akPP3":
        Script32();
        break;
      case "6FepDKDbsWj":
        Script33();
        break;
      case "5pqs9WZiEh0":
        Script34();
        break;
      case "6KZBXiNVcxH":
        Script35();
        break;
      case "6M27CePKX1u":
        Script36();
        break;
      case "5lmHpb1iVti":
        Script37();
        break;
      case "5YHZ6BfyL6o":
        Script38();
        break;
      case "6eIhecOshL7":
        Script39();
        break;
      case "6BqLejUJT1B":
        Script40();
        break;
      case "6h36T190Ug8":
        Script41();
        break;
      case "6LGVEvBPkzz":
        Script42();
        break;
      case "6GUkucXNZTB":
        Script43();
        break;
      case "5gG6EY0MrPi":
        Script44();
        break;
      case "6bquvhotSso":
        Script45();
        break;
      case "643S17ez7EK":
        Script46();
        break;
      case "5nm3nj5PciT":
        Script47();
        break;
      case "6VOeFTPkDaA":
        Script48();
        break;
      case "6ofEkx461M0":
        Script49();
        break;
      case "5dIzDtrrkEt":
        Script50();
        break;
      case "6N6QZYTFvWr":
        Script51();
        break;
      case "5saNEyRG70T":
        Script52();
        break;
      case "6pDoxsseYtf":
        Script53();
        break;
      case "6r1M2rGryzW":
        Script54();
        break;
      case "667mVnIaxwN":
        Script55();
        break;
      case "6l5oS5CqRk6":
        Script56();
        break;
      case "5cDKD3yeaIN":
        Script57();
        break;
      case "6h5wHPFTqUR":
        Script58();
        break;
      case "68HwmBmku9O":
        Script59();
        break;
      case "6NE8i7Xe3pH":
        Script60();
        break;
      case "61KUMZdvXs6":
        Script61();
        break;
      case "6NTySnXRWLq":
        Script62();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script2()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script3()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script4()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script5()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script6()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script7()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script8()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script9()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script10()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script11()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script12()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script13()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script14()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script15()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script16()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script17()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script18()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script19()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script20()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script21()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script22()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script23()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script24()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script25()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script26()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script27()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script28()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script29()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script30()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script31()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script32()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script33()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script34()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script35()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script36()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script37()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script38()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script39()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script40()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script41()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script42()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script43()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script44()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script45()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script46()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script47()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script48()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script49()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script50()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script51()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script52()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script53()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script54()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script55()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script56()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script57()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script58()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script59()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script60()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script61()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script62()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

