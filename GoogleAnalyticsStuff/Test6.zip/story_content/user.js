function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6TOgSbDtLl3":
        Script1();
        break;
      case "69yl8NaRMAU":
        Script2();
        break;
      case "663b6HKYZbt":
        Script3();
        break;
      case "5ohbvwsAxex":
        Script4();
        break;
      case "6SCHS62gpzg":
        Script5();
        break;
      case "627CFnl747b":
        Script6();
        break;
      case "67Tk7YGVwYc":
        Script7();
        break;
      case "6r01Op1qiSP":
        Script8();
        break;
      case "5gn0rTcHxVg":
        Script9();
        break;
      case "6kHOPXCZhBX":
        Script10();
        break;
      case "6Wn8XD8Kd8o":
        Script11();
        break;
      case "6ZmZA79ceBH":
        Script12();
        break;
      case "6TKhkxQNZF7":
        Script13();
        break;
      case "6V65UoOyyOh":
        Script14();
        break;
      case "6aWnJgmPm5g":
        Script15();
        break;
      case "5mbJXnb3OlF":
        Script16();
        break;
      case "6UIVI8nuoDY":
        Script17();
        break;
      case "6EeZ77hIcDZ":
        Script18();
        break;
      case "60Nhze1HelM":
        Script19();
        break;
      case "5dbWT5jeg56":
        Script20();
        break;
      case "6L4oiJs211Y":
        Script21();
        break;
      case "5kUQpMBDs2D":
        Script22();
        break;
      case "6UpVafKGlYw":
        Script23();
        break;
      case "5y1nJ7IBrJ7":
        Script24();
        break;
      case "5aGaPDAa7xd":
        Script25();
        break;
      case "6As6ZeITFcB":
        Script26();
        break;
      case "5VqYf4WWqaW":
        Script27();
        break;
      case "68zXE26cu72":
        Script28();
        break;
      case "5oQR97yPBJA":
        Script29();
        break;
      case "5lfduTfUdLt":
        Script30();
        break;
      case "5vMGKqLyvq4":
        Script31();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script2()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script3()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script4()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script5()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script6()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script7()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script8()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script9()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script10()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script11()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script12()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script13()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script14()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script15()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script16()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script17()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script18()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script19()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script20()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script21()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script22()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script23()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script24()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script25()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script26()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script27()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script28()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script29()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script30()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

function Script31()
{
  var player = GetPlayer();

// Google Analytics account identifier
var ACCOUNT = player.GetVar('ACCOUNT');

// Type (page, event)
var TRACK_AS_PAGE = player.GetVar('TRACK_AS_PAGE');

// Page tracking
var MODULE = player.GetVar('MODULE');
var LOCATION = player.GetVar('LOCATION');
var TITLE = player.GetVar('TITLE');

// Event tracking
var CATEGORY = player.GetVar('CATEGORY');
var ACTION = player.GetVar('ACTION');
var LABEL = player.GetVar('LABEL');
var VALUE = player.GetVar('VALUE');

// Initialize Google Analytics if not done already
if(typeof sga === 'undefined') {
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','sga');

if(isset(ACCOUNT)) {
sga('create', ACCOUNT, 'auto');
}
}


// Additional dimension tracking for host name and module designation
sga('set', 'dimension1', location.hostname);
if(isset(MODULE)) sga('set', 'dimension2', MODULE);

// Set user ID if it can be found
var userIdDom = null;
var userId = null;
userIdDom = parent.document.getElementById('nav-message-popover-container');

if(userIdDom) userId = userIdDom.getAttribute('data-userid');
if(userId) {
sga('set', 'userId', userId);
}

// Track based on type
// Page tracking
if(TRACK_AS_PAGE) {
if(allset([MODULE, LOCATION, TITLE])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION, TITLE);
}
else if(allset([MODULE, LOCATION])) {
sga('send', 'pageview', '/' + MODULE + '/' + LOCATION);
}
}
// Event tracking
else {
if(allset([CATEGORY, ACTION, LABEL, VALUE])) {
sga('send', 'event', CATEGORY, ACTION, LABEL, VALUE);
}
else if(allset([CATEGORY, ACTION, LABEL])) {
sga('send', 'event', CATEGORY, ACTION, LABEL);
}
else if(allset([CATEGORY, ACTION])) {
sga('send', 'event', CATEGORY, ACTION);
}
}

// Utility functions
function isset(prop) {
return typeof prop !== 'undefined';
}

function allset(arr) {
for(var i = 0; i < arr.length; i++) {
if(!isset(arr[i])) return false;
}
return true;
}

}

